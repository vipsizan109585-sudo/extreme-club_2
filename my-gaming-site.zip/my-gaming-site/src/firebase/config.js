import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyADELRNMhHB_BkBrLVDwO044FepmjCUZeA",
  authDomain: "extreme-club-3-0.firebaseapp.com",
  projectId: "extreme-club-3-0",
  storageBucket: "extreme-club-3-0.firebasestorage.app",
  messagingSenderId: "892897216369",
  appId: "1:892897216369:web:c192e809c18db66b8798d0"
};

let app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
export const db = getFirestore(app);