"use client";
import { useState, useEffect } from 'react';
import { auth, db } from '@/firebase/config';
import { doc, getDoc, addDoc, collection, serverTimestamp, increment, updateDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function WithdrawPage() {
  const [balance, setBalance] = useState(0);
  const [amount, setAmount] = useState("");
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      getDoc(doc(db, "users", user.uid)).then(s => setBalance(s.data()?.balance || 0));
    } else {
      router.push("/login");
    }
  }, [router]);

  const handleWithdraw = async () => {
    const user = auth.currentUser;
    const withdrawAmt = Number(amount);

    if (withdrawAmt < 500) return alert("সর্বনিম্ন উইথড্র ৫০০ টাকা");
    if (withdrawAmt > balance) return alert("আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই");
    
    setLoading(true);
    try {
      const userSnap = await getDoc(doc(db, "users", user.uid));
      const userData = userSnap.data();

      if (!userData.withdrawPin || userData.withdrawPin !== pin) {
        setLoading(false);
        return alert("ভুল উইথড্র পিন! প্রোফাইল থেকে পিন সেট করুন।");
      }

      // ১. ব্যালেন্স হোল্ড করা (টাকা কেটে নেওয়া)
      await updateDoc(doc(db, "users", user.uid), {
        balance: increment(-withdrawAmt)
      });

      // ২. উইথড্র রিকোয়েস্ট ডাটাবেজে পাঠানো
      await addDoc(collection(db, "withdrawals"), {
        uid: user.uid,
        phone: userData.phone,
        amount: withdrawAmt,
        status: "pending",
        createdAt: serverTimestamp()
      });

      alert("Withdrawal Request সফল হয়েছে! ২-২৪ ঘণ্টার মধ্যে পেমেন্ট পাবেন।");
      router.push("/profile");
    } catch (e) {
      alert(e.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#090c15] text-white p-6 font-sans">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => router.back()} className="text-2xl text-gray-400">←</button>
        <h1 className="text-xl font-black text-yellow-500 italic uppercase">Withdraw Funds</h1>
      </div>

      {/* Available Balance Info */}
      <div className="bg-[#161d2f] p-6 rounded-3xl border border-gray-800 mb-8">
        <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Available for Withdrawal</p>
        <h2 className="text-3xl font-black text-white mt-1">৳ {balance.toFixed(2)}</h2>
      </div>

      {/* Input Fields */}
      <div className="space-y-6">
        <div>
          <label className="text-[10px] text-gray-500 uppercase font-bold ml-2">Withdraw Amount</label>
          <input 
            type="number" 
            placeholder="Min ৳500" 
            className="w-full bg-[#161d2f] border border-gray-800 p-4 rounded-2xl mt-2 outline-none focus:border-yellow-500 text-lg font-bold"
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div>
          <label className="text-[10px] text-gray-500 uppercase font-bold ml-2">6-Digit Withdrawal PIN</label>
          <input 
            type="password" 
            maxLength="6"
            placeholder="......" 
            className="w-full bg-[#161d2f] border border-gray-800 p-4 rounded-2xl mt-2 outline-none focus:border-yellow-500 tracking-[0.5em] text-center"
            onChange={(e) => setPin(e.target.value)}
          />
        </div>

        <div className="bg-yellow-500/5 p-4 rounded-2xl border border-yellow-500/10">
          <p className="text-[10px] text-yellow-500/70 leading-relaxed italic">
            * Withdrawal সময় সকাল ১০টা থেকে রাত ১০টা। <br/>
            * পেমেন্ট পেতে ২-২৪ ঘণ্টা সময় লাগতে পারে।
          </p>
        </div>

        <button 
          onClick={handleWithdraw}
          disabled={loading}
          className={`w-full py-4 rounded-2xl font-black text-sm shadow-xl transition-all ${loading ? 'bg-gray-700' : 'bg-yellow-500 text-black active:scale-95'}`}
        >
          {loading ? "PROCESSING..." : "CONFIRM WITHDRAWAL"}
        </button>
      </div>
    </div>
  );
}