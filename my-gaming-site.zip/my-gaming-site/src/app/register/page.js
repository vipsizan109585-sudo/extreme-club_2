"use client";
import { useState } from 'react';
import { auth, db } from "@/firebase/config";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import Link from 'next/link';

export default function RegisterPage() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const router = useRouter();

  const handleRegister = async (e) => {
    e.preventDefault();
    
    // ফোন নম্বরকে ইমেইল ফরম্যাটে কনভার্ট করা (ফায়ারবেস অথেন্টিকেশনের জন্য সহজ পদ্ধতি)
    const fakeEmail = `${phone}@extreme.club`;

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, fakeEmail, password);
      const user = userCredential.user;

      // ডাটাবেজে ইউজার প্রোফাইল তৈরি
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        phone: phone,
        balance: 20, // নতুন ইউজার রেজিস্ট্রেশন বোনাস
        inviteCode: inviteCode || "none",
        role: "user",
        createdAt: new Date()
      });

      alert("রেজিস্ট্রেশন সফল হয়েছে! আপনাকে ২০ টাকা বোনাস দেওয়া হয়েছে।");
      router.push("/");
    } catch (error) {
      alert("ভুল হয়েছে: " + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#090c15] text-white flex flex-col justify-center p-6">
      <div className="max-w-md w-full mx-auto bg-[#161d2f] p-8 rounded-[2.5rem] border border-gray-800 shadow-2xl">
        <h1 className="text-3xl font-black mb-2 text-yellow-500 italic uppercase">Register</h1>
        <p className="text-gray-400 text-sm mb-8 font-medium">Create your account to start winning!</p>

        <form onSubmit={handleRegister} className="space-y-5">
          <div>
            <label className="text-xs text-gray-500 ml-1 uppercase tracking-widest">Phone Number</label>
            <input 
              type="text" 
              placeholder="01XXXXXXXXX" 
              className="w-full bg-[#0f172a] border border-gray-700 p-4 rounded-2xl outline-none focus:border-yellow-500 transition font-bold"
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="text-xs text-gray-500 ml-1 uppercase tracking-widest">Set Password</label>
            <input 
              type="password" 
              placeholder="••••••••" 
              className="w-full bg-[#0f172a] border border-gray-700 p-4 rounded-2xl outline-none focus:border-yellow-500 transition"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="text-xs text-gray-500 ml-1 uppercase tracking-widest">Invite Code (Optional)</label>
            <input 
              type="text" 
              placeholder="Enter Code" 
              className="w-full bg-[#0f172a] border border-gray-700 p-4 rounded-2xl outline-none focus:border-yellow-500 transition"
              onChange={(e) => setInviteCode(e.target.value)}
            />
          </div>

          <button type="submit" className="w-full bg-yellow-500 py-4 rounded-2xl text-black font-black text-lg shadow-xl shadow-yellow-500/20 active:scale-95 transition mt-4">
            Register Now
          </button>
        </form>

        <p className="mt-8 text-center text-gray-400 text-sm">
          Already have an account? <Link href="/login" className="text-yellow-500 font-bold underline">Login</Link>
        </p>
      </div>
    </div>
  );
}