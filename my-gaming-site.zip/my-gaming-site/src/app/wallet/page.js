"use client";
import { useState, useEffect } from 'react';
import { auth, db } from '@/firebase/config';
import { doc, onSnapshot } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function WalletPage() {
  const [balance, setBalance] = useState(0);
  const router = useRouter();

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      onSnapshot(doc(db, "users", user.uid), (s) => setBalance(s.data()?.balance || 0));
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#090c15] text-white p-6 pb-24 font-sans">
      <h1 className="text-xl font-black text-yellow-500 mb-8 italic uppercase tracking-tighter">My Wallet</h1>

      {/* Main Balance Card */}
      <div className="bg-gradient-to-br from-[#1e263b] to-[#111827] p-8 rounded-[2.5rem] border border-gray-800 shadow-2xl text-center mb-8 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl"></div>
        <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Total Available Balance</p>
        <h2 className="text-4xl font-black text-yellow-500">৳ {balance.toFixed(2)}</h2>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => router.push('/deposit')} className="bg-yellow-500 p-6 rounded-[2rem] text-black font-black flex flex-col items-center gap-2 shadow-lg shadow-yellow-500/10">
          <span className="text-2xl">➕</span>
          <span className="text-xs uppercase">Deposit</span>
        </button>
        <button onClick={() => router.push('/withdraw')} className="bg-[#161d2f] p-6 rounded-[2rem] text-white border border-gray-800 font-black flex flex-col items-center gap-2">
          <span className="text-2xl">📤</span>
          <span className="text-xs uppercase">Withdraw</span>
        </button>
      </div>

      {/* Internal Menu */}
      <div className="mt-8 space-y-3">
        <div className="bg-[#161d2f] p-5 rounded-2xl flex justify-between items-center border border-gray-800">
          <span className="text-sm">Deposit History</span>
          <span className="text-gray-600">→</span>
        </div>
        <div className="bg-[#161d2f] p-5 rounded-2xl flex justify-between items-center border border-gray-800">
          <span className="text-sm">Withdrawal History</span>
          <span className="text-gray-600">→</span>
        </div>
      </div>
    </div>
  );

  // Wallet পেজে এটি যোগ করুন
const [transactions, setTransactions] = useState([]);

useEffect(() => {
  const q = query(collection(db, "withdrawals"), where("uid", "==", auth.currentUser.uid), orderBy("createdAt", "desc"));
  onSnapshot(q, (snap) => {
    setTransactions(snap.docs.map(doc => doc.data()));
  });
}, []);

// UI Table
<div className="mt-8 bg-[#161d2f] rounded-3xl p-4">
  <h3 className="text-xs font-bold text-gray-500 uppercase mb-4">Withdraw History</h3>
  {transactions.map((t, i) => (
    <div key={i} className="flex justify-between border-b border-gray-800 py-3">
      <div>
        <p className="font-bold">৳{t.amount}</p>
        <p className="text-[10px] text-gray-500">{t.createdAt?.toDate().toLocaleString()}</p>
      </div>
      <span className={`text-[10px] font-bold ${t.status === 'pending' ? 'text-yellow-500' : 'text-green-500'}`}>
        {t.status.toUpperCase()}
      </span>
    </div>
  ))}
</div>