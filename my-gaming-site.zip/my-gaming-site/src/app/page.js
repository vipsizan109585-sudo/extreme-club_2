"use client";
import { useState, useEffect } from 'react';
import { auth, db } from '@/firebase/config';
import { 
  doc, onSnapshot, updateDoc, increment, collection, 
  addDoc, serverTimestamp, query, orderBy, limit, getDoc, getDocs, where, deleteDoc 
} from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useRouter } from "next/navigation";

export default function WinGoMain() {
  const [user, setUser] = useState(null);
  const [balance, setBalance] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [selectedAmount, setSelectedAmount] = useState(10);
  const [history, setHistory] = useState([]);
  const [betPopup, setBetPopup] = useState({ show: false, type: '', value: '' });
  const [showNotice, setShowNotice] = useState(true);
  const [myBets, setMyBets] = useState([]);
  const router = useRouter();

  // ১. ইউনিক পিরিয়ড আইডি জেনারেটর
  const getPeriodId = () => {
    const now = new Date();
    const datePart = now.getFullYear().toString() + (now.getMonth() + 1).toString().padStart(2, '0') + now.getDate().toString().padStart(2, '0');
    const totalMin = now.getHours() * 60 + now.getMinutes();
    return `${datePart}${totalMin.toString().padStart(4, '0')}`;
  };

  // ২. ডাটা লোডিং (ব্যালেন্স, হিস্ট্রি, মাই বেটস)
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      if (u) {
        setUser(u);
        onSnapshot(doc(db, "users", u.uid), (s) => setBalance(s.data()?.balance || 0));
        
        // ইউজারের নিজের বেট হিস্ট্রি
        const qMy = query(collection(db, "current_bets"), where("uid", "==", u.uid), orderBy("createdAt", "desc"), limit(10));
        onSnapshot(qMy, (s) => setMyBets(s.docs.map(d => ({ id: d.id, ...d.data() }))));
      } else { router.push("/login"); }
    });

    const qHis = query(collection(db, "game_results"), orderBy("createdAt", "desc"), limit(15));
    onSnapshot(qHis, (s) => setHistory(s.docs.map(d => d.data())));

    return () => unsubAuth();
  }, [router]);

  // ৩. টাইমার লজিক
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timeLeft === 1) handleRoundEnd(); 
          return 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  // ৪. রাউন্ড শেষ হলে রেজাল্ট এবং সেটেলমেন্ট
  const handleRoundEnd = async () => {
    try {
      const settingsRef = doc(db, "game_settings", "next_result");
      const settingsSnap = await getDoc(settingsRef);
      let res;

      if (settingsSnap.exists()) {
        res = settingsSnap.data();
        await deleteDoc(settingsRef);
      } else {
        const n = Math.floor(Math.random() * 10);
        res = {
          number: n,
          color: (n === 0 || n === 5) ? 'Violet' : (n % 2 === 0 ? 'Red' : 'Green'),
          size: n >= 5 ? 'Big' : 'Small'
        };
      }

      const period = getPeriodId();
      await addDoc(collection(db, "game_results"), { ...res, period, createdAt: serverTimestamp() });
      
      // অটো সেটেলমেন্ট ফাংশন কল
      settleUsers(res, period);
    } catch (e) { console.error(e); }
  };

  const settleUsers = async (res, period) => {
    const q = query(collection(db, "current_bets"), where("status", "==", "pending"));
    const snap = await getDocs(q);
    snap.forEach(async (betDoc) => {
      const bet = betDoc.data();
      let win = false;
      if (bet.type === 'color' && bet.selection === res.color) win = true;
      if (bet.type === 'size' && bet.selection === res.size) win = true;
      if (bet.type === 'number' && Number(bet.selection) === res.number) win = true;

      if (win) {
        const multiply = bet.type === 'number' ? 9 : 1.98;
        await updateDoc(doc(db, "users", bet.uid), { balance: increment(bet.amount * multiply) });
      }
      await updateDoc(doc(db, "current_bets", betDoc.id), { status: "settled", result: win ? "Win" : "Loss" });
    });
  };

  // ৫. বেট সাবমিট
  const placeBet = async () => {
    if (balance < selectedAmount) return alert("Insufficient Balance!");
    if (timeLeft < 5) return alert("Time Over for this round!");

    try {
      await updateDoc(doc(db, "users", user.uid), { balance: increment(-selectedAmount) });
      await addDoc(collection(db, "current_bets"), {
        uid: user.uid,
        type: betPopup.type,
        selection: betPopup.value,
        amount: selectedAmount,
        status: "pending",
        period: getPeriodId(),
        createdAt: serverTimestamp()
      });
      setBetPopup({ show: false, type: '', value: '' });
    } catch (e) { alert(e.message); }
  };

  return (
    <div className="min-h-screen bg-[#090c15] text-white font-sans pb-24">
      {/* Navbar */}
      <nav className="p-4 flex justify-between items-center bg-[#161d2f] border-b border-gray-800 sticky top-0 z-50">
        <h1 className="text-xl font-black text-yellow-500 italic uppercase">DK WIN PRO</h1>
        <div className="bg-[#1e263b] px-4 py-1.5 rounded-full border border-yellow-500/30 text-yellow-500 font-bold">৳ {balance.toFixed(2)}</div>
      </nav>

      {/* Timer Display */}
      <div className="m-4 p-6 bg-gradient-to-br from-[#1e263b] to-black rounded-[2rem] border border-gray-800 flex justify-between items-center">
        <div>
          <p className="text-yellow-500 text-[10px] font-bold uppercase tracking-widest">Win Go 1Min</p>
          <p className="text-xs text-gray-500">Period: {getPeriodId()}</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-gray-500 uppercase">Count Down</p>
          <p className="text-3xl font-black text-yellow-500 font-mono">00:{timeLeft < 10 ? `0${timeLeft}` : timeLeft}</p>
        </div>
      </div>

      {/* Game Buttons */}
      <div className="px-4 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <button onClick={() => setBetPopup({show:true, type:'color', value:'Green'})} className="bg-green-600 h-14 rounded-2xl font-bold">Green</button>
          <button onClick={() => setBetPopup({show:true, type:'color', value:'Violet'})} className="bg-purple-600 h-14 rounded-2xl font-bold">Violet</button>
          <button onClick={() => setBetPopup({show:true, type:'color', value:'Red'})} className="bg-red-600 h-14 rounded-2xl font-bold">Red</button>
        </div>
        <div className="grid grid-cols-5 gap-2 bg-[#161d2f] p-4 rounded-3xl border border-gray-800">
          {[0,1,2,3,4,5,6,7,8,9].map(n => (
            <button key={n} onClick={() => setBetPopup({show:true, type:'number', value:n})} className="h-10 rounded-full border border-gray-700 text-yellow-500 font-bold">{n}</button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => setBetPopup({show:true, type:'size', value:'Big'})} className="bg-orange-500 py-4 rounded-2xl font-black italic">BIG</button>
          <button onClick={() => setBetPopup({show:true, type:'size', value:'Small'})} className="bg-blue-500 py-4 rounded-2xl font-black italic">SMALL</button>
        </div>
      </div>

      {/* Betting Popup */}
      {betPopup.show && (
        <div className="fixed inset-0 z-[110] flex items-end bg-black/60 backdrop-blur-sm">
          <div className="w-full bg-[#161d2f] rounded-t-[2.5rem] p-8 animate-in slide-in-from-bottom border-t border-yellow-500/20">
            <h3 className="text-lg font-black text-yellow-500 mb-6 uppercase tracking-tighter">Confirm Bet: {betPopup.value}</h3>
            <div className="flex gap-2 overflow-x-auto mb-8">
              {[10, 50, 100, 500, 1000].map(amt => (
                <button key={amt} onClick={() => setSelectedAmount(amt)} className={`px-6 py-2 rounded-xl font-bold border ${selectedAmount === amt ? 'bg-yellow-500 text-black border-yellow-500' : 'border-gray-800'}`}>৳{amt}</button>
              ))}
            </div>
            <div className="flex gap-4">
              <button onClick={() => setBetPopup({show:false})} className="flex-1 bg-gray-800 py-4 rounded-2xl font-bold">Cancel</button>
              <button onClick={placeBet} className="flex-2 bg-yellow-500 text-black px-12 py-4 rounded-2xl font-black">Confirm</button>
            </div>
          </div>
        </div>
      )}

      {/* History & My Bets */}
      <div className="m-4 bg-[#161d2f] rounded-3xl overflow-hidden border border-gray-800">
        <div className="flex border-b border-gray-800">
          <button className="flex-1 py-4 text-xs font-bold text-yellow-500 border-b-2 border-yellow-500">History</button>
          <button className="flex-1 py-4 text-xs font-bold text-gray-500">My Bets</button>
        </div>
        <table className="w-full text-center text-[10px]">
          <thead className="bg-[#090c15] text-gray-500">
            <tr><th className="py-3">Period</th><th>Result</th><th>Size</th><th>Color</th></tr>
          </thead>
          <tbody>
            {history.map((h, i) => (
              <tr key={i} className="border-b border-gray-800/50">
                <td className="py-3 opacity-50">{h.period}</td>
                <td className={`font-black text-lg ${h.color === 'Red' ? 'text-red-500' : 'text-green-500'}`}>{h.number}</td>
                <td className="uppercase">{h.size}</td>
                <td><div className={`w-2 h-2 rounded-full mx-auto ${h.color === 'Red' ? 'bg-red-500' : 'bg-green-500'}`}></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Bottom Nav */}
      <footer className="fixed bottom-0 w-full bg-[#0f172a]/95 backdrop-blur-xl border-t border-gray-800 p-4 flex justify-around rounded-t-[2.5rem]">
        <button onClick={() => router.push('/')} className="text-yellow-500 text-2xl">🏠</button>
        <button onClick={() => router.push('/promotion')} className="text-gray-400 text-2xl">📢</button>
        <button onClick={() => router.push('/wallet')} className="text-gray-400 text-2xl">💰</button>
        <button onClick={() => router.push('/profile')} className="text-gray-400 text-2xl">👤</button>
      </footer>
    </div>
  );
}