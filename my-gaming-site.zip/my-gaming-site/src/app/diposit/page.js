"use client";
import { useState } from 'react';
import { db, auth } from '@/firebase/config';
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function DepositPage() {
  const [amount, setAmount] = useState("");
  const [trxId, setTrxId] = useState("");
  const [method, setMethod] = useState("Bkash");
  const router = useRouter();

  // আপনার পার্সোনাল নাম্বারগুলো এখানে দিন
  const adminNumbers = {
    Bkash: "017XXXXXXXX", 
    Nagad: "018XXXXXXXX",
    Rocket: "019XXXXXXXX"
  };

  const handleDeposit = async () => {
    if (!amount || !trxId) return alert("সবগুলো তথ্য সঠিকভাবে দিন");
    if (amount < 200) return alert("সর্বনিম্ন ডিপোজিট ২০০ টাকা");

    try {
      await addDoc(collection(db, "deposits"), {
        uid: auth.currentUser.uid,
        email: auth.currentUser.email,
        amount: Number(amount),
        method: method,
        trxId: trxId,
        status: "pending",
        createdAt: serverTimestamp()
      });
      alert("ডিপোজিট রিকোয়েস্ট সফল! অ্যাডমিন ভেরিফাই করলে ব্যালেন্স যোগ হবে।");
      router.push("/profile");
    } catch (e) { alert(e.message); }
  };

  const copyNumber = () => {
    navigator.clipboard.writeText(adminNumbers[method]);
    alert(`${method} নাম্বার কপি হয়েছে!`);
  };

  return (
    <div className="min-h-screen bg-[#090c15] text-white p-6 pb-24 font-sans">
      <h1 className="text-xl font-black text-yellow-500 mb-8 italic uppercase">Recharge Balance</h1>

      {/* Select Method */}
      <div className="grid grid-cols-3 gap-3 mb-8">
        {Object.keys(adminNumbers).map((m) => (
          <button key={m} onClick={() => setMethod(m)} 
            className={`py-3 rounded-2xl font-bold text-xs border transition ${method === m ? 'bg-yellow-500 border-yellow-500 text-black' : 'bg-[#161d2f] border-gray-800 text-gray-400'}`}>
            {m}
          </button>
        ))}
      </div>

      {/* Admin Number Card */}
      <div className="bg-[#161d2f] p-6 rounded-[2rem] border border-gray-800 text-center mb-8">
        <p className="text-[10px] text-gray-500 uppercase mb-2">Send Money to this {method} Number</p>
        <h2 className="text-2xl font-black text-white tracking-widest mb-4">{adminNumbers[method]}</h2>
        <button onClick={copyNumber} className="bg-yellow-500/10 text-yellow-500 px-6 py-2 rounded-full text-[10px] font-black border border-yellow-500/20">COPY NUMBER</button>
      </div>

      {/* Input Form */}
      <div className="space-y-4">
        <input type="number" placeholder="Enter Amount (Min ৳200)" className="w-full bg-[#161d2f] p-4 rounded-2xl outline-none border border-gray-800 focus:border-yellow-500" onChange={(e)=>setAmount(e.target.value)} />
        <input type="text" placeholder="Enter Transaction ID (TrxID)" className="w-full bg-[#161d2f] p-4 rounded-2xl outline-none border border-gray-800 focus:border-yellow-500 uppercase" onChange={(e)=>setTrxId(e.target.value)} />
        
        <div className="bg-blue-500/5 p-4 rounded-2xl border border-blue-500/10">
          <p className="text-[10px] text-blue-400 leading-relaxed italic">
            * টাকা পাঠানোর পর TrxID এখানে দিন। ভুল TrxID দিলে অ্যাকাউন্ট ব্যান হতে পারে।
          </p>
        </div>

        <button onClick={handleDeposit} className="w-full bg-yellow-500 text-black py-4 rounded-2xl font-black shadow-lg shadow-yellow-500/20 active:scale-95 transition">SUBMIT RECHARGE</button>
      </div>
    </div>
  );
}