/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: '#090c15',
        cardBg: '#161d2f',
        accent: '#eab308',
      },
    },
  },
  plugins: [],
}