"use client";
import { useState, useEffect } from 'react';
import { auth, db } from '@/firebase/config';
import { doc, onSnapshot, query, collection, where, getDocs } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function PromotionPage() {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [subordinates, setSubordinates] = useState(0); // কতজন রেফার হয়েছে
  const router = useRouter();

  useEffect(() => {
    const unsubAuth = auth.onAuthStateChanged((u) => {
      if (u) {
        setUser(u);
        onSnapshot(doc(db, "users", u.uid), (s) => setUserData(s.data()));
        
        // রেফারেল সংখ্যা গোনা
        const q = query(collection(db, "users"), where("inviteCode", "==", u.uid));
        getDocs(q).then(snap => setSubordinates(snap.size));
      } else {
        router.push("/login");
      }
    });
    return () => unsubAuth();
  }, [router]);

  const copyLink = () => {
    const link = `${window.location.origin}/register?invite=${user?.uid}`;
    navigator.clipboard.writeText(link);
    alert("Invitation link copied!");
  };

  if (!userData) return <div className="min-h-screen bg-black text-white p-10">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#090c15] text-white font-sans pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-600 to-yellow-400 p-8 text-black text-center rounded-b-[3rem] shadow-2xl">
        <h1 className="text-2xl font-black italic mb-1 uppercase">Agency Center</h1>
        <p className="text-xs font-bold opacity-70">Invite friends to earn high commissions</p>
      </div>

      {/* Commission Data Card */}
      <div className="grid grid-cols-2 gap-4 p-6 -mt-10">
        <div className="bg-[#161d2f] p-6 rounded-3xl border border-gray-800 text-center shadow-xl">
          <p className="text-[10px] text-gray-500 uppercase mb-2">Total Commission</p>
          <p className="text-xl font-black text-yellow-500">৳ {(userData.commission || 0).toFixed(2)}</p>
        </div>
        <div className="bg-[#161d2f] p-6 rounded-3xl border border-gray-800 text-center shadow-xl">
          <p className="text-[10px] text-gray-500 uppercase mb-2">Subordinates</p>
          <p className="text-xl font-black text-blue-500">{subordinates}</p>
        </div>
      </div>

      {/* Invitation Link Section */}
      <div className="mx-6 mt-4 bg-[#161d2f] p-8 rounded-[2rem] border border-dashed border-yellow-500/30 text-center">
        <p className="text-xs text-gray-400 mb-4 uppercase tracking-[0.2em]">Your Unique Invite Link</p>
        <div className="bg-[#090c15] p-3 rounded-xl mb-6 font-mono text-[10px] text-yellow-500/80 truncate">
          {`${window.location.origin}/register?invite=${user?.uid}`}
        </div>
        <button 
          onClick={copyLink}
          className="w-full bg-yellow-500 text-black py-4 rounded-2xl font-black text-sm shadow-lg shadow-yellow-500/20 active:scale-95 transition"
        >
          COPY INVITATION LINK
        </button>
      </div>

      {/* Reward Rules */}
      <div className="p-6">
        <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
          <span className="w-1.5 h-4 bg-yellow-500 rounded-full"></span>
          Commission Levels
        </h3>
        <div className="space-y-3">
          <div className="bg-[#161d2f] p-4 rounded-2xl flex justify-between items-center border border-gray-800">
            <span className="text-xs text-gray-400">Level 1 (Direct)</span>
            <span className="text-green-500 font-bold">0.6% Reward</span>
          </div>
          <div className="bg-[#161d2f] p-4 rounded-2xl flex justify-between items-center border border-gray-800 opacity-60">
            <span className="text-xs text-gray-400">Level 2 (Indirect)</span>
            <span className="text-blue-500 font-bold">0.3% Reward</span>
          </div>
        </div>
      </div>

      {/* Footer Nav (উইথ প্রোমোশন বাটন) */}
      <footer className="fixed bottom-0 w-full bg-[#0f172a]/95 backdrop-blur-md p-4 flex justify-around border-t border-gray-800 z-50">
        <button onClick={() => router.push('/')} className="text-gray-400 text-2xl">🏠</button>
        <button onClick={() => router.push('/promotion')} className="text-yellow-500 text-2xl">📢</button>
        <button onClick={() => router.push('/deposit')} className="text-gray-400 text-2xl">💰</button>
        <button onClick={() => router.push('/profile')} className="text-gray-400 text-2xl">👤</button>
      </footer>
    </div>
  );
}