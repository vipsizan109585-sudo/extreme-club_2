"use client";
import { auth, db } from "@/firebase/config";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // চেক করা হচ্ছে ইউজার কি নতুন নাকি পুরাতন
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        // নতুন ইউজার হলে ডাটাবেজে এন্ট্রি এবং ১০০ টাকা বোনাস
        await setDoc(userRef, {
          uid: user.uid,
          name: user.displayName,
          email: user.email,
          balance: 100, // সাইনআপ বোনাস
          createdAt: new Date(),
        });
      }
      
      router.push("/"); // লগইন সফল হলে হোম পেজে নিয়ে যাবে
    } catch (error) {
      console.error("Login Error:", error);
      alert("লগইন ব্যর্থ হয়েছে!");
    }
  };

  return (
    <div className="min-h-screen bg-[#090c15] flex flex-col items-center justify-center p-6 text-white">
      <div className="w-full max-w-md bg-[#161d2f] p-10 rounded-[2.5rem] border border-gray-800 shadow-2xl text-center">
        <div className="w-20 h-20 bg-yellow-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-yellow-500/20">
          <span className="text-4xl">🎮</span>
        </div>
        <h1 className="text-3xl font-black mb-2 italic">EXTREME CLUB</h1>
        <p className="text-gray-400 mb-10">Welcome! Please login to start winning.</p>

        <button 
          onClick={handleLogin}
          className="w-full bg-white text-black font-bold py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-gray-200 transition active:scale-95"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/action/google.svg" className="w-6" alt="google" />
          Continue with Google
        </button>

        <p className="mt-8 text-[10px] text-gray-500 px-6 uppercase tracking-widest">
          By continuing, you agree to our terms and conditions.
        </p>
      </div>
    </div>
  );
}