"use client";
import { useState, useEffect } from 'react';
import { auth, db } from '@/firebase/config';
import { doc, onSnapshot, updateDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";

export default function ProfilePage() {
  const [userData, setUserData] = useState(null);
  const [pin, setPin] = useState("");
  const router = useRouter();

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((user) => {
      if (user) {
        onSnapshot(doc(db, "users", user.uid), (snap) => {
          setUserData(snap.data());
        });
      } else {
        router.push("/login");
      }
    });
    return () => unsub();
  }, [router]);

  const handleUpdatePin = async () => {
    if (pin.length !== 6) return alert("দয়া করে ৬ সংখ্যার পিন দিন");
    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        withdrawPin: pin
      });
      alert("Withdrawal PIN সফলভাবে সেট করা হয়েছে!");
      setPin("");
    } catch (e) { alert(e.message); }
  };

  const handleLogout = () => {
    signOut(auth).then(() => router.push("/login"));
  };

  if (!userData) return <div className="min-h-screen bg-black flex items-center justify-center text-white">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#090c15] text-white pb-24 font-sans">
      {/* Header Section */}
      <div className="bg-gradient-to-b from-yellow-600 to-[#090c15] p-8 text-center rounded-b-[3rem]">
        <div className="w-20 h-20 bg-[#161d2f] rounded-full mx-auto mb-4 border-4 border-yellow-500 flex items-center justify-center text-3xl">
          👤
        </div>
        <h2 className="text-xl font-black">{userData.phone || "User"}</h2>
        <p className="text-xs text-black font-bold bg-yellow-500 px-3 py-1 rounded-full inline-block mt-2">UID: {auth.currentUser.uid.slice(0, 8)}</p>
      </div>

      {/* Balance Card */}
      <div className="mx-6 -mt-10 bg-[#161d2f] p-6 rounded-[2rem] border border-gray-800 shadow-2xl flex justify-between items-center">
        <div>
          <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Total Balance</p>
          <h3 className="text-2xl font-black text-yellow-500 mt-1">৳ {userData.balance?.toFixed(2)}</h3>
        </div>
        <button onClick={() => router.push('/wallet')} className="bg-yellow-500 text-black px-4 py-2 rounded-xl font-bold text-xs">Wallet</button>
      </div>

      {/* Security: Set Withdrawal PIN */}
      <div className="m-6 bg-[#161d2f] p-6 rounded-3xl border border-gray-800">
        <h4 className="text-sm font-bold text-gray-400 mb-4 flex items-center gap-2">
          <span className="text-yellow-500">🔒</span> Security Settings
        </h4>
        <p className="text-[10px] text-gray-500 mb-2 uppercase tracking-widest">Set 6-Digit Withdrawal PIN</p>
        <div className="flex gap-2">
          <input 
            type="password" 
            maxLength="6"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="......" 
            className="flex-1 bg-[#090c15] border border-gray-800 rounded-xl p-3 text-center text-yellow-500 font-bold tracking-[0.5em] outline-none focus:border-yellow-500"
          />
          <button onClick={handleUpdatePin} className="bg-yellow-500 text-black px-6 rounded-xl font-bold text-xs">Set</button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-6 space-y-3">
        <button onClick={() => router.push('/promotion')} className="w-full bg-[#161d2f] p-4 rounded-2xl flex justify-between items-center border border-gray-800">
          <span className="text-sm">Agency Center (Refer & Earn)</span>
          <span className="text-gray-600">→</span>
        </button>
        <button onClick={() => router.push('/wallet')} className="w-full bg-[#161d2f] p-4 rounded-2xl flex justify-between items-center border border-gray-800">
          <span className="text-sm">Transaction History</span>
          <span className="text-gray-600">→</span>
        </button>
        <button onClick={handleLogout} className="w-full bg-red-600/10 text-red-500 p-4 rounded-2xl font-bold border border-red-500/20 mt-4">
          Logout
        </button>
      </div>

      {/* Navigation Footer */}
      <footer className="fixed bottom-0 w-full bg-[#0f172a]/95 backdrop-blur-md p-4 flex justify-around border-t border-gray-800">
        <button onClick={() => router.push('/')} className="text-gray-400 text-2xl">🏠</button>
        <button onClick={() => router.push('/promotion')} className="text-gray-400 text-2xl">📢</button>
        <button onClick={() => router.push('/deposit')} className="text-gray-400 text-2xl">💰</button>
        <button onClick={() => router.push('/profile')} className="text-yellow-500 text-2xl">👤</button>
      </footer>
    </div>
  );
}