"use client";
import { useState, useEffect } from 'react';
import { db } from '@/firebase/config';
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "users"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  return (
    <div className="min-h-screen bg-[#05070a] text-white p-6">
      <h1 className="text-xl font-black text-yellow-500 mb-6 italic">USER MANAGEMENT</h1>
      <div className="overflow-x-auto">
        <table className="w-full text-left bg-[#111622] rounded-3xl overflow-hidden border border-gray-800">
          <thead className="bg-[#1a2035] text-gray-400 text-[10px] uppercase">
            <tr>
              <th className="p-4">Phone/Email</th>
              <th className="p-4">Balance</th>
              <th className="p-4">Commission</th>
              <th className="p-4">Status</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {users.map(u => (
              <tr key={u.id} className="border-b border-gray-800">
                <td className="p-4">{u.phone || u.email || u.uid.slice(0,8)}</td>
                <td className="p-4 text-yellow-500 font-bold">৳{u.balance?.toFixed(2)}</td>
                <td className="p-4 text-green-500 font-bold">৳{u.commission?.toFixed(2) || 0}</td>
                <td className="p-4"><span className="bg-green-900/20 text-green-500 px-2 py-1 rounded text-[10px]">Active</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}